import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  final bool isRoot;
  const ProfileScreen({super.key, this.isRoot = false});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with TickerProviderStateMixin {
  late AnimationController _headerController;
  late AnimationController _listController;

  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  bool _biometricEnabled = true;

  final List<Map<String, dynamic>> _settingsSections = [
    {
      'title': 'Account Settings',
      'items': [
        {'title': 'Edit Profile', 'subtitle': 'Update your personal information', 'icon': Icons.person_outline_rounded, 'color': Color(0xFF667eea), 'action': 'editProfile'},
        {'title': 'Change Password', 'subtitle': 'Update your password', 'icon': Icons.lock_outline_rounded, 'color': Color(0xFFffa726), 'action': 'changePassword'},
        {'title': 'Business Details', 'subtitle': 'Manage your business information', 'icon': Icons.business_rounded, 'color': Color(0xFF66bb6a), 'action': ''},
      ],
    },
    {
      'title': 'Data & Storage',
      'items': [
        {'title': 'Export Data', 'subtitle': 'Download your data as Excel/PDF', 'icon': Icons.download_rounded, 'color': Color(0xFF667eea), 'action': 'exportData'},
        {'title': 'Backup & Restore', 'subtitle': 'Backup your data to cloud', 'icon': Icons.cloud_upload_rounded, 'color': Color(0xFF42a5f5), 'action': ''},
        {'title': 'Clear Cache', 'subtitle': 'Free up storage space', 'icon': Icons.cleaning_services_rounded, 'color': Color(0xFFffa726), 'action': 'clearCache'},
      ],
    },
    {
      'title': 'Support & Legal',
      'items': [
        {'title': 'Help Center', 'subtitle': 'Get help and support', 'icon': Icons.help_outline_rounded, 'color': Color(0xFF667eea), 'action': ''},
        {'title': 'Privacy Policy', 'subtitle': 'Read our privacy policy', 'icon': Icons.privacy_tip_outlined, 'color': Color(0xFF66bb6a), 'action': ''},
        {'title': 'Terms of Service', 'subtitle': 'View terms and conditions', 'icon': Icons.description_outlined, 'color': Color(0xFF764ba2), 'action': ''},
        {'title': 'About', 'subtitle': 'Version 1.0.0', 'icon': Icons.info_outline_rounded, 'color': Color(0xFF42a5f5), 'action': 'about'},
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
    _headerController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _listController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..forward();
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool showBack = !widget.isRoot;
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildAnimatedAppBar(showBack),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildProfileCard(),
                _buildStatsRow(),
                const SizedBox(height: 8),
                _buildPreferencesSection(),
                ..._buildSettingsSections(),
                const SizedBox(height: 16),
                _buildLogoutButton(),
                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== ANIMATED APP BAR (FIXED - MATCHES INVENTORY) ====================
  Widget _buildAnimatedAppBar(bool showBack) {
    return SliverAppBar(
      expandedHeight: showBack ? 150 : 120,  // exactly like InventoryScreen
      floating: false,
      pinned: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leading: showBack
          ? IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.25),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
        ),
        onPressed: () => Navigator.pop(context),
      )
          : null,
      flexibleSpace: FlexibleSpaceBar(
        background: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, -0.5), end: Offset.zero).animate(
            CurvedAnimation(parent: _headerController, curve: Curves.easeOutCubic),
          ),
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF667eea), Color(0xFF764ba2)],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  showBack ? 24 : 12,   // left padding: 24 when back button, else 12
                  showBack ? 50 : 0,    // top padding: 50 when back button, else 0
                  24,
                  20,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Profile',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Manage your account',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.qr_code_rounded, color: Colors.white),
          onPressed: () {},
        ),
      ],
    );
  }

  // ==================== PROFILE CARD ====================
  Widget _buildProfileCard() {
    return FadeTransition(
      opacity: _headerController,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
          CurvedAnimation(parent: _headerController, curve: Curves.easeOutCubic),
        ),
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF667eea), Color(0xFF764ba2)],
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF667eea).withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            children: [
              Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [Colors.orange, Colors.pink]),
                    ),
                    child: const CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.white,
                      child: Icon(Icons.person, size: 50, color: Color(0xFF667eea)),
                    ),
                  ),
                  Positioned(
                    right: 0, bottom: 0,
                    child: GestureDetector(
                      onTap: () => _changeProfilePicture(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 2)),
                          ],
                        ),
                        child: const Icon(Icons.camera_alt_rounded, color: Color(0xFF667eea), size: 20),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Muhammad Usman', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              const Text('abc@example.com', style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w500)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.verified_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 6),
                    Text('Premium Member', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== STATS ROW ====================
  Widget _buildStatsRow() {
    final stats = [
      {'value': '1,247', 'label': 'Items', 'icon': Icons.inventory_2_rounded},
      {'value': 'PKR 45K', 'label': 'Expenses', 'icon': Icons.attach_money_rounded},
      {'value': '24', 'label': 'Reports', 'icon': Icons.analytics_rounded},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: stats.asMap().entries.map((entry) {
          final index = entry.key;
          final stat = entry.value;
          return Expanded(
            child: SlideTransition(
              position: Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
                CurvedAnimation(
                  parent: _listController,
                  curve: Interval(0.1 * index, 0.4 + (0.1 * index), curve: Curves.easeOutCubic),
                ),
              ),
              child: FadeTransition(
                opacity: _listController,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                    ],
                  ),
                  child: Column(
                    children: [
                      Icon(stat['icon'] as IconData, color: const Color(0xFF667eea), size: 24),
                      const SizedBox(height: 8),
                      Text(stat['value'] as String, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF2d3748))),
                      const SizedBox(height: 4),
                      Text(stat['label'] as String, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ==================== PREFERENCES SECTION ====================
  Widget _buildPreferencesSection() {
    return Column(
      children: [
        _buildSectionTitle('Preferences'),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            children: [
              _buildSwitchTile('Push Notifications', 'Receive alerts and updates', Icons.notifications_outlined, const Color(0xFF667eea), _notificationsEnabled, (v) => setState(() => _notificationsEnabled = v)),
              _buildSwitchTile('Dark Mode', 'Enable dark theme', Icons.dark_mode_outlined, const Color(0xFF764ba2), _darkModeEnabled, (v) => setState(() => _darkModeEnabled = v)),
              _buildSwitchTile('Biometric Login', 'Use fingerprint or face ID', Icons.fingerprint_rounded, const Color(0xFF66bb6a), _biometricEnabled, (v) => setState(() => _biometricEnabled = v)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, IconData icon, Color color, bool value, Function(bool) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF2d3748))),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged, activeColor: color),
        ],
      ),
    );
  }

  // ==================== SETTINGS SECTIONS ====================
  List<Widget> _buildSettingsSections() {
    List<Widget> widgets = [];
    for (int sIndex = 0; sIndex < _settingsSections.length; sIndex++) {
      final section = _settingsSections[sIndex];
      widgets.add(_buildSectionTitle(section['title'] as String));
      widgets.add(
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            children: (section['items'] as List<Map<String, dynamic>>).asMap().entries.map((entry) {
              final itemIndex = entry.key;
              final item = entry.value;
              return SlideTransition(
                position: Tween<Offset>(begin: const Offset(0.2, 0), end: Offset.zero).animate(
                  CurvedAnimation(
                    parent: _listController,
                    curve: Interval(0.2 + (sIndex * 0.1) + (itemIndex * 0.05), 0.6 + (sIndex * 0.1) + (itemIndex * 0.05), curve: Curves.easeOutCubic),
                  ),
                ),
                child: FadeTransition(
                  opacity: _listController,
                  child: _buildSettingsTile(
                    item['title'] as String,
                    item['subtitle'] as String,
                    item['icon'] as IconData,
                    item['color'] as Color,
                        () => _handleAction(item['action'] as String),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      );
    }
    return widgets;
  }

  Widget _buildSettingsTile(String title, String subtitle, IconData icon, Color color, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF2d3748))),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400, size: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF2d3748))),
      ),
    );
  }

  // ==================== LOGOUT BUTTON ====================
  Widget _buildLogoutButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
          CurvedAnimation(parent: _listController, curve: Curves.easeOutCubic),
        ),
        child: FadeTransition(
          opacity: _listController,
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _logout(),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Logout', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== ACTION HANDLERS ====================
  void _handleAction(String action) {
    switch (action) {
      case 'editProfile':
        _editProfile();
        break;
      case 'changePassword':
        _changePassword();
        break;
      case 'exportData':
        _exportData();
        break;
      case 'clearCache':
        _clearCache();
        break;
      case 'about':
        _showAbout();
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Coming soon')));
    }
  }

  void _editProfile() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Edit Profile'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(decoration: InputDecoration(labelText: 'Name', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            const SizedBox(height: 16),
            TextField(decoration: InputDecoration(labelText: 'Email', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile updated successfully')));
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF667eea)),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _changePassword() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Change Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(obscureText: true, decoration: InputDecoration(labelText: 'Current Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            const SizedBox(height: 16),
            TextField(obscureText: true, decoration: InputDecoration(labelText: 'New Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            const SizedBox(height: 16),
            TextField(obscureText: true, decoration: InputDecoration(labelText: 'Confirm Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password changed successfully')));
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFffa726)),
            child: const Text('Change'),
          ),
        ],
      ),
    );
  }

  void _changeProfilePicture() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 24),
            const Text('Change Profile Picture', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 24),
            ListTile(leading: const Icon(Icons.camera_alt_rounded, color: Color(0xFF667eea)), title: const Text('Take Photo'), onTap: () => Navigator.pop(context)),
            ListTile(leading: const Icon(Icons.photo_library_rounded, color: Color(0xFF66bb6a)), title: const Text('Choose from Gallery'), onTap: () => Navigator.pop(context)),
            ListTile(leading: const Icon(Icons.delete_rounded, color: Colors.red), title: const Text('Remove Photo'), onTap: () => Navigator.pop(context)),
          ],
        ),
      ),
    );
  }

  void _exportData() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Export Format', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 24),
            ListTile(
              leading: const Icon(Icons.file_present_rounded, color: Color(0xFF66bb6a)),
              title: const Text('Export as Excel'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Exporting as Excel...')));
              },
            ),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_rounded, color: Color(0xFFf5576c)),
              title: const Text('Export as PDF'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Exporting as PDF...')));
              },
            ),
          ],
        ),
      ),
    );
  }

  void _clearCache() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Clear Cache'),
        content: const Text('This will free up storage space. Continue?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cache cleared successfully')));
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFffa726)),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _showAbout() {
    showAboutDialog(
      context: context,
      applicationName: 'Inventory Manager',
      applicationVersion: '1.0.0',
      applicationIcon: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF667eea), Color(0xFF764ba2)]), borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.inventory_2_rounded, color: Colors.white, size: 32),
      ),
      children: const [Text('A powerful inventory and expense tracker with AI-powered insights.')],
    );
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Logged out successfully')));
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }
}